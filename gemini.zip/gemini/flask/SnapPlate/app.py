import os
import io
from flask import Flask, request, jsonify
from flask_cors import CORS
from google import genai
from google.genai import types
from PIL import Image

app = Flask(__name__)
CORS(app)  # Enable CORS for PHP API

# Use environment variable for API key
api_key = os.getenv("GEMINI_API_KEY", "AIzaSyAmXgZQ7IED09eBb78-aD7WtSoG9F9aFxQ")
print(f"Using Gemini API Key: {api_key[:10]}...")
client = genai.Client(api_key=api_key)

@app.route("/generate", methods=["POST"])
def generate_recipe():
    try:
        # Get image path from PHP API
        data = request.get_json()
        
        if not data or 'image_path' not in data:
            return jsonify({"error": "No image path provided"}), 400
        
        image_path = data['image_path']
        
        # Convert relative path to absolute path
        # PHP uploads to api/uploads/, Flask needs to access it from flask/SnapPlate/
        if not os.path.isabs(image_path):
            # Go up two directories from flask/SnapPlate/ to reach api/uploads/
            image_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'api', image_path)
        
        # Check if file exists
        if not os.path.exists(image_path):
            return jsonify({"error": f"Image file not found at: {image_path}"}), 404
        
        # Read and process image using PIL
        image = Image.open(image_path)
        
        print(f"Processing image: {image_path}, size: {image.size}")
        
        # Generate recipe using Gemini with correct format
        print("Sending request to Gemini AI...")
        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=[
                "Create a simple recipe and steps using the leftover foods in this image. Include ingredients list and cooking instructions.",
                image
            ]
        )
        
        print("Received response from Gemini AI")
        return jsonify({"recipe": response.text})
        
    except Exception as e:
        return jsonify({"error": f"AI processing failed: {str(e)}"}), 500

if __name__ == "__main__":
    # Get port from environment variable or use default
    port = int(os.getenv("FLASK_PORT", 5000))
    app.run(debug=True, host='127.0.0.1', port=port)






