<?php
// Gemini AI Service - Direct API call tanpa Flask
class GeminiService {
    private $api_key;
    private $api_url;
    
    public function __construct() {
        $this->api_key = "AIzaSyAmXgZQ7IED09eBb78-aD7WtSoG9F9aFxQ";
        $this->api_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=" . $this->api_key;
    }
    
    public function generateRecipe($image_path) {
        try {
            // Check if file exists
            if (!file_exists($image_path)) {
                return array(
                    'success' => false,
                    'error' => 'Image file not found: ' . $image_path
                );
            }
            
            // Prepare image data
            $image_data = base64_encode(file_get_contents($image_path));
            $image_mime = mime_content_type($image_path);
            
            // Prepare request data
            $request_data = array(
                "contents" => array(
                    array(
                        "parts" => array(
                            array(
                                "text" => "Create a simple recipe and steps using the leftover foods in this image. Include ingredients list and cooking instructions."
                            ),
                            array(
                                "inline_data" => array(
                                    "mime_type" => $image_mime,
                                    "data" => $image_data
                                )
                            )
                        )
                    )
                )
            );
            
            // Make API call
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $this->api_url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($request_data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 60);
            
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curl_error = curl_error($ch);
            curl_close($ch);
            
            if ($http_code == 200 && $response) {
                $gemini_response = json_decode($response, true);
                
                if ($gemini_response && isset($gemini_response['candidates'][0]['content']['parts'][0]['text'])) {
                    $recipe_text = $gemini_response['candidates'][0]['content']['parts'][0]['text'];
                    
                    return array(
                        'success' => true,
                        'recipe' => $recipe_text,
                        'source' => 'Gemini AI'
                    );
                } else {
                    return array(
                        'success' => false,
                        'error' => 'Invalid Gemini response format'
                    );
                }
            } else {
                return array(
                    'success' => false,
                    'error' => 'Gemini API error: ' . ($curl_error ?: "HTTP Code: " . $http_code)
                );
            }
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'error' => 'Exception: ' . $e->getMessage()
            );
        }
    }
}
?>
