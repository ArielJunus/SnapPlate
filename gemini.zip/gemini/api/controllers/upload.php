<?php
// Disable error reporting to prevent HTML output
error_reporting(0);
ini_set('display_errors', 0);

// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Recipe.php';
require_once 'gemini_service.php';

// Simple JWT decode function
function decodeJWT($token) {
    if (!$token) return false;
    
    try {
        $decoded = json_decode(base64_decode($token), true);
        if ($decoded && isset($decoded['exp']) && $decoded['exp'] > time()) {
            return $decoded;
        }
    } catch (Exception $e) {
        // Invalid token format
    }
    return false;
}

// Get authorization header
$headers = getallheaders();
$token = null;

if (isset($headers['Authorization'])) {
    $token = str_replace('Bearer ', '', $headers['Authorization']);
}

// For testing, let's be more lenient with authentication
$user_data = decodeJWT($token);

if (!$user_data) {
    // For testing purposes, create a default user data
    $user_data = array(
        'user_id' => 1,
        'username' => 'testuser',
        'email' => 'test@example.com'
    );
}

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Initialize Recipe object
$recipe = new Recipe($db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Handle file upload
    if (isset($_FILES['image'])) {
        $file = $_FILES['image'];
        
        // File validation
        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp');
        $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        
        if (!in_array($file_extension, $allowed_extensions)) {
            http_response_code(400);
            echo json_encode(array(
                "message" => "Invalid file extension. Only image files allowed.",
                "received_extension" => $file_extension,
                "file_name" => $file['name']
            ));
            exit();
        }
        
        // Generate unique filename
        $filename = uniqid() . '_' . $file['name'];
        $upload_path = '../uploads/' . $filename;
        
        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $upload_path)) {
            
            // Use Gemini AI service directly
            $gemini_service = new GeminiService();
            $ai_result = $gemini_service->generateRecipe($upload_path);
            
            if ($ai_result['success']) {
                // Save recipe to database
                $recipe->user_id = $user_data['user_id'];
                $recipe->image_path = $upload_path;
                $recipe->recipe_content = $ai_result['recipe'];
                
                if ($recipe->save()) {
                    http_response_code(201);
                    echo json_encode(array(
                        "message" => "Recipe generated successfully by Gemini AI.",
                        "recipe" => $ai_result['recipe'],
                        "image_path" => $upload_path,
                        "source" => $ai_result['source']
                    ));
                } else {
                    http_response_code(201);
                    echo json_encode(array(
                        "message" => "Recipe generated successfully by Gemini AI (database save failed).",
                        "recipe" => $ai_result['recipe'],
                        "image_path" => $upload_path,
                        "source" => $ai_result['source']
                    ));
                }
            } else {
                // Fallback to mock recipe if Gemini AI fails
                $mock_recipe = "Delicious recipe for your ingredients:\n\n1. Clean and prepare your ingredients\n2. Heat oil in a pan\n3. Add ingredients and cook for 10 minutes\n4. Season to taste\n5. Serve hot and enjoy!";
                
                http_response_code(201);
                echo json_encode(array(
                    "message" => "Recipe generated successfully (Gemini AI unavailable).",
                    "recipe" => $mock_recipe,
                    "image_path" => $upload_path,
                    "source" => "Fallback Recipe",
                    "gemini_error" => $ai_result['error']
                ));
            }
            
        } else {
            http_response_code(500);
            echo json_encode(array("message" => "Failed to upload file."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "No image file provided."));
    }
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Method not allowed."));
}
?>
