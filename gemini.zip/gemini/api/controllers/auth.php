<?php
// Disable error reporting to prevent HTML output
error_reporting(0);
ini_set('display_errors', 0);

// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/User.php';

// Get database connection
try {
    $database = new Database();
    $db = $database->getConnection();
    
    if (!$db) {
        http_response_code(500);
        echo json_encode(array("message" => "Database connection failed."));
        exit();
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array("message" => "Database error: " . $e->getMessage()));
    exit();
}

// Initialize User object
$user = new User($db);

// Get posted data
$input = file_get_contents("php://input");
$data = json_decode($input);

// Debug logging
error_log("Auth API - Input: " . $input);
error_log("Auth API - Decoded data: " . print_r($data, true));

if (!$data) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid JSON data."));
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($data->action)) {
        
        if ($data->action == 'register') {
            // Register user
            $user->username = $data->username;
            $user->email = $data->email;
            $user->password = $data->password;
            
            if ($user->emailExists()) {
                http_response_code(400);
                echo json_encode(array("message" => "Email already exists."));
            } else {
                if ($user->register()) {
                    http_response_code(201);
                    echo json_encode(array("message" => "User registered successfully."));
                } else {
                    http_response_code(400);
                    echo json_encode(array("message" => "Unable to register user."));
                }
            }
        }
        
        elseif ($data->action == 'login') {
            // Login user
            $user->email = $data->email;
            $user->password = $data->password;
            
            if ($user->login()) {
                // Generate JWT token (simple implementation)
                $token = base64_encode(json_encode(array(
                    "user_id" => $user->id,
                    "username" => $user->username,
                    "email" => $user->email,
                    "exp" => time() + (24 * 60 * 60) // 24 hours
                )));
                
                http_response_code(200);
                echo json_encode(array(
                    "message" => "Login successful.",
                    "token" => $token,
                    "user" => array(
                        "id" => $user->id,
                        "username" => $user->username,
                        "email" => $user->email
                    )
                ));
            } else {
                http_response_code(401);
                echo json_encode(array("message" => "Invalid email or password."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Invalid action."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Action is required."));
    }
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Method not allowed."));
}
?>
