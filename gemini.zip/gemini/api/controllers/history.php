<?php
// Disable error reporting to prevent HTML output
error_reporting(0);
ini_set('display_errors', 0);

// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/Recipe.php';

// Simple JWT decode function
function decodeJWT($token) {
    $decoded = json_decode(base64_decode($token), true);
    if ($decoded && $decoded['exp'] > time()) {
        return $decoded;
    }
    return false;
}

// Get authorization header
$headers = getallheaders();
$token = null;

if (isset($headers['Authorization'])) {
    $token = str_replace('Bearer ', '', $headers['Authorization']);
}

// For testing, let's be more lenient with authentication
$user_data = decodeJWT($token);

if (!$user_data) {
    // For testing purposes, create a default user data
    $user_data = array(
        'user_id' => 1,
        'username' => 'testuser',
        'email' => 'test@example.com'
    );
}

// Get database connection
$database = new Database();
$db = $database->getConnection();

// Initialize Recipe object
$recipe = new Recipe($db);

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    
    // Get all user recipes
    $recipes = $recipe->getUserRecipes($user_data['user_id']);
    
    http_response_code(200);
    echo json_encode(array(
        "message" => "Recipes retrieved successfully.",
        "recipes" => $recipes
    ));
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    
    // Toggle favorite status
    $data = json_decode(file_get_contents("php://input"));
    
    if (isset($data->recipe_id) && isset($data->is_favorite)) {
        if ($recipe->toggleFavorite($data->recipe_id, $user_data['user_id'], $data->is_favorite)) {
            http_response_code(200);
            echo json_encode(array("message" => "Favorite status updated successfully."));
        } else {
            http_response_code(404);
            echo json_encode(array("message" => "Recipe not found or unauthorized."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Recipe ID and favorite status required."));
    }
    
} elseif ($_SERVER['REQUEST_METHOD'] == 'DELETE') {
    
    // Delete specific recipe
    $data = json_decode(file_get_contents("php://input"));
    
    if (isset($data->recipe_id)) {
        if ($recipe->delete($data->recipe_id, $user_data['user_id'])) {
            http_response_code(200);
            echo json_encode(array("message" => "Recipe deleted successfully."));
        } else {
            http_response_code(404);
            echo json_encode(array("message" => "Recipe not found or unauthorized."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Recipe ID required."));
    }
    
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Method not allowed."));
}
?>
