<?php
// Disable error reporting to prevent HTML output
error_reporting(0);
ini_set('display_errors', 0);

// CORS Headers
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../models/User.php';

// Get database connection
try {
    $database = new Database();
    $db = $database->getConnection();
    
    if (!$db) {
        http_response_code(500);
        echo json_encode(array("message" => "Database connection failed."));
        exit();
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array("message" => "Database error: " . $e->getMessage()));
    exit();
}

// Initialize User object
$user = new User($db);

// Get posted data
$input = file_get_contents("php://input");
$data = json_decode($input);

// Debug logging
error_log("Profile API - Input: " . $input);
error_log("Profile API - Decoded data: " . print_r($data, true));

if (!$data) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid JSON data."));
    exit();
}

// Simple JWT token verification (decode the token)
function verifyToken($token) {
    try {
        $decoded = json_decode(base64_decode($token), true);
        if ($decoded && isset($decoded['exp']) && $decoded['exp'] > time()) {
            return $decoded;
        }
        return false;
    } catch (Exception $e) {
        return false;
    }
}

// Get Authorization header
$headers = getallheaders();
$token = null;

if (isset($headers['Authorization'])) {
    $auth_header = $headers['Authorization'];
    if (preg_match('/Bearer\s+(.*)$/i', $auth_header, $matches)) {
        $token = $matches[1];
    }
}

if (!$token) {
    http_response_code(401);
    echo json_encode(array("message" => "Access token required."));
    exit();
}

$token_data = verifyToken($token);
if (!$token_data) {
    http_response_code(401);
    echo json_encode(array("message" => "Invalid or expired token."));
    exit();
}

$user_id = $token_data['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    // Get user profile
    $user_data = $user->getUserById($user_id);
    if ($user_data) {
        http_response_code(200);
        echo json_encode(array(
            "message" => "Profile retrieved successfully.",
            "user" => $user_data
        ));
    } else {
        http_response_code(404);
        echo json_encode(array("message" => "User not found."));
    }
} elseif ($_SERVER['REQUEST_METHOD'] == 'PUT') {
    // Update user profile
    if (isset($data->action)) {
        
        if ($data->action == 'update_profile') {
            // Update username and/or email
            $new_username = isset($data->username) ? $data->username : null;
            $new_email = isset($data->email) ? $data->email : null;
            
            // Check if username already exists (if changing username)
            if ($new_username !== null) {
                $user->username = $new_username;
                if ($user->usernameExists()) {
                    // Check if it's the same user
                    $current_user = $user->getUserById($user_id);
                    if ($current_user['username'] !== $new_username) {
                        http_response_code(400);
                        echo json_encode(array("message" => "Username already exists."));
                        exit();
                    }
                }
            }
            
            // Check if email already exists (if changing email)
            if ($new_email !== null) {
                $user->email = $new_email;
                if ($user->emailExists()) {
                    // Check if it's the same user
                    $current_user = $user->getUserById($user_id);
                    if ($current_user['email'] !== $new_email) {
                        http_response_code(400);
                        echo json_encode(array("message" => "Email already exists."));
                        exit();
                    }
                }
            }
            
            if ($user->updateProfile($user_id, $new_username, $new_email)) {
                // Get updated user data
                $updated_user = $user->getUserById($user_id);
                http_response_code(200);
                echo json_encode(array(
                    "message" => "Profile updated successfully.",
                    "user" => $updated_user
                ));
            } else {
                http_response_code(400);
                echo json_encode(array("message" => "Unable to update profile."));
            }
        }
        
        elseif ($data->action == 'update_password') {
            // Update password
            if (!isset($data->current_password) || !isset($data->new_password)) {
                http_response_code(400);
                echo json_encode(array("message" => "Current password and new password are required."));
                exit();
            }
            
            // Verify current password
            if (!$user->verifyPassword($user_id, $data->current_password)) {
                http_response_code(400);
                echo json_encode(array("message" => "Current password is incorrect."));
                exit();
            }
            
            if ($user->updatePassword($user_id, $data->new_password)) {
                http_response_code(200);
                echo json_encode(array("message" => "Password updated successfully."));
            } else {
                http_response_code(400);
                echo json_encode(array("message" => "Unable to update password."));
            }
        } else {
            http_response_code(400);
            echo json_encode(array("message" => "Invalid action."));
        }
    } else {
        http_response_code(400);
        echo json_encode(array("message" => "Action is required."));
    }
} else {
    http_response_code(405);
    echo json_encode(array("message" => "Method not allowed."));
}
?>
