<?php
// SnapPlate API Configuration

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'snapplate');
define('DB_USER', 'root');
define('DB_PASS', '');

// API Configuration
define('API_VERSION', 'v1');
define('JWT_SECRET', 'snapplate_secret_key_2024');

// CORS Configuration
define('ALLOWED_ORIGINS', '*');

// Error Reporting (for development)
define('DEBUG_MODE', true);

if (DEBUG_MODE) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}
?>
