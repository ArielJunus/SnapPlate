<?php
require_once '../config/database.php';

class Recipe {
    private $conn;
    private $table_name = "recipes";

    public $id;
    public $user_id;
    public $image_path;
    public $recipe_content;
    public $is_favorite;
    public $created_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Save recipe
    public function save() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET user_id=:user_id, image_path=:image_path, recipe_content=:recipe_content";
        
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(":user_id", $this->user_id);
        $stmt->bindParam(":image_path", $this->image_path);
        $stmt->bindParam(":recipe_content", $this->recipe_content);
        
        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    // Get user recipes
    public function getUserRecipes($user_id) {
        $query = "SELECT id, image_path, recipe_content, is_favorite, created_at 
                  FROM " . $this->table_name . " 
                  WHERE user_id = :user_id 
                  ORDER BY created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get single recipe
    public function getRecipe($id) {
        $query = "SELECT id, user_id, image_path, recipe_content, is_favorite, created_at 
                  FROM " . $this->table_name . " 
                  WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        
        if($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    // Toggle favorite status
    public function toggleFavorite($id, $user_id, $is_favorite) {
        $query = "UPDATE " . $this->table_name . " 
                  SET is_favorite = :is_favorite 
                  WHERE id = :id AND user_id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":is_favorite", $is_favorite);
        $stmt->bindParam(":id", $id);
        $stmt->bindParam(":user_id", $user_id);
        
        return $stmt->execute();
    }

    // Delete recipe
    public function delete($id, $user_id) {
        $query = "DELETE FROM " . $this->table_name . " 
                  WHERE id = :id AND user_id = :user_id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->bindParam(":user_id", $user_id);
        
        return $stmt->execute();
    }
}
?>
