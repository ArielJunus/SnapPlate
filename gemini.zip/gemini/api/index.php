<?php
// CORS Headers - must be set before any output
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Access-Control-Max-Age: 86400');
header('Content-Type: application/json');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config/config.php';

// Simple routing
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);

// Debug: log the request
error_log("Request URI: " . $request_uri);
error_log("Path: " . $path);

// Remove base path - sesuaikan dengan struktur hosting
$path = str_replace('/api/', '', $path);
$path = str_replace('/api', '', $path);
$path = ltrim($path, '/');

error_log("Clean path: " . $path);

switch ($path) {
    case 'auth':
    case 'auth/':
        require_once 'controllers/auth.php';
        break;
    case 'upload':
    case 'upload/':
        require_once 'controllers/upload.php';
        break;
    case 'history':
    case 'history/':
        require_once 'controllers/history.php';
        break;
    case 'profile':
    case 'profile/':
        require_once 'controllers/profile.php';
        break;
    case '':
        // Root API endpoint
        echo json_encode(array("message" => "SnapPlate API is running!"));
        break;
    default:
        http_response_code(404);
        echo json_encode(array("message" => "Endpoint not found: " . $path));
        break;
}
?>
