import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class AppConfig {
  // Environment configuration - auto-detect based on platform
  static Environment get environment {
    if (kIsWeb) {
      print('AppConfig: Detected Web environment');
      return Environment.web;
    } else if (defaultTargetPlatform == TargetPlatform.android) {
      print('AppConfig: Detected Android environment - using production URL');
      return Environment.production; // Use production for Android
    } else {
      print('AppConfig: Detected Local environment');
      return Environment.local;
    }
  }
  
  // Local development configuration
  static const String localApiHost = 'localhost';
  static const String localApiPort = '80'; // Default HTTP port
  static const String localFlaskPort = '5000';
  
  // Android emulator configuration
  static const String androidApiHost = '10.0.2.2';
  static const String androidApiPort = '80'; // Use port 80 for Android
  
  // Debug configuration - force specific URL for Android
  static String get debugBaseUrl {
    if (kIsWeb) {
      return 'https://fluttersnapplate.jokifigma.cloud/api';
    } else if (defaultTargetPlatform == TargetPlatform.android) {
      // Use production URL for Android since localhost doesn't work
      return 'https://fluttersnapplate.jokifigma.cloud/api';
    } else {
      return 'http://localhost:80/gemini/api';
    }
  }
  
  // API URLs based on environment
  static String get baseUrl {
    String url;
    switch (environment) {
      case Environment.local:
        url = 'http://$localApiHost:$localApiPort/gemini/api';
        break;
      case Environment.androidEmulator:
        url = debugBaseUrl; // Use debug configuration for Android
        break;
      case Environment.web:
        url = 'https://fluttersnapplate.jokifigma.cloud/api';
        break;
      case Environment.production:
        url = 'https://fluttersnapplate.jokifigma.cloud/api';
        break;
    }
    print('AppConfig: Using baseUrl: $url');
    return url;
  }
  
  // Flask AI service URL (tidak digunakan lagi karena sudah terintegrasi ke PHP API)
  static String get flaskUrl {
    switch (environment) {
      case Environment.local:
        return 'http://$localApiHost:$localFlaskPort';
      case Environment.androidEmulator:
        return 'http://10.0.2.2:$localFlaskPort';
      case Environment.web:
        return 'https://fluttersnapplate.jokifigma.cloud';
      case Environment.production:
        return 'https://fluttersnapplate.jokifigma.cloud';
    }
  }
}

enum Environment {
  local,
  androidEmulator,
  web,
  production,
}
