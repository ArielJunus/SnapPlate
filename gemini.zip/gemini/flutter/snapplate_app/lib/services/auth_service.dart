import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user.dart';
import 'api_service.dart';

class AuthService {
  static const String _tokenKey = 'auth_token';
  static const String _userKey = 'user_data';

  // Save user session
  static Future<void> saveUserSession(User user, String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
    await prefs.setString(_userKey, jsonEncode(user.toJson()));
    ApiService.setToken(token);
  }

  // Get current user
  static Future<User?> getCurrentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final userData = prefs.getString(_userKey);
    
    if (userData != null) {
      try {
        final userJson = jsonDecode(userData);
        return User.fromJson(userJson);
      } catch (e) {
        print('Error parsing user data: $e');
        return null;
      }
    }
    
    return null;
  }

  // Check if user is logged in
  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString(_tokenKey);
    
    if (token != null) {
      ApiService.setToken(token);
      return true;
    }
    
    return false;
  }

  // Logout user
  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_userKey);
    ApiService.logout();
  }

  // Get stored token
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  // Update user data in local storage
  static Future<void> updateUserData({String? username, String? email}) async {
    final prefs = await SharedPreferences.getInstance();
    final userData = prefs.getString(_userKey);
    
    if (userData != null) {
      try {
        final userJson = jsonDecode(userData);
        final user = User.fromJson(userJson);
        
        // Update the fields if provided
        if (username != null) {
          user.username = username;
        }
        if (email != null) {
          user.email = email;
        }
        
        // Save updated user data
        await prefs.setString(_userKey, jsonEncode(user.toJson()));
      } catch (e) {
        print('Error updating user data: $e');
      }
    }
  }
}
