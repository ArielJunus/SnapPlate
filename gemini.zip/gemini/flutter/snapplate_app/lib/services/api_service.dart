import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/foundation.dart';
import '../models/user.dart';
import '../models/recipe.dart';
import '../config/app_config.dart';

class ApiService {
  // Konfigurasi URL untuk development
  static String get baseUrl => AppConfig.baseUrl;
  static String? _token;

  static void setToken(String token) {
    _token = token;
  }

  static Map<String, String> get _headers {
    Map<String, String> headers = {
      'Content-Type': 'application/json',
    };
    
    if (kIsWeb) {
      headers['X-Requested-With'] = 'XMLHttpRequest';
    }
    
    if (_token != null) {
      headers['Authorization'] = 'Bearer $_token';
    }
    
    return headers;
  }

  // Authentication
  static Future<AuthResponse> login(String email, String password) async {
    try {
      final url = '$baseUrl/auth';
      print('Login API URL: $url'); // Debug log
      
      final response = await http.post(
        Uri.parse(url),
        headers: _headers,
        body: jsonEncode({
          'action': 'login',
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final authResponse = AuthResponse.fromJson(data);
        
        if (authResponse.token != null) {
          setToken(authResponse.token!);
        }
        
        return authResponse;
      } else {
        String errorMessage = 'Login failed';
        try {
          if (response.body.isNotEmpty) {
            final error = jsonDecode(response.body);
            errorMessage = error['message'] ?? errorMessage;
          }
        } catch (e) {
          errorMessage = 'Server error (${response.statusCode})';
        }
        throw Exception(errorMessage);
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  static Future<AuthResponse> register(String username, String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/auth'),
        headers: _headers,
        body: jsonEncode({
          'action': 'register',
          'username': username,
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 201) {
        final data = jsonDecode(response.body);
        return AuthResponse.fromJson(data);
      } else {
        String errorMessage = 'Registration failed';
        try {
          if (response.body.isNotEmpty) {
            final error = jsonDecode(response.body);
            errorMessage = error['message'] ?? errorMessage;
          }
        } catch (e) {
          errorMessage = 'Server error (${response.statusCode})';
        }
        throw Exception(errorMessage);
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Upload and generate recipe
  static Future<RecipeResponse> uploadImageAndGenerateRecipe(dynamic imageFile) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/upload'),
      );

      // Add headers
      request.headers.addAll(_headers);

      // Add image file - support both mobile and web
      if (kIsWeb) {
        // For web, imageFile is Uint8List
        request.files.add(
          http.MultipartFile.fromBytes(
            'image',
            imageFile,
            filename: 'image.jpg',
          ),
        );
      } else {
        // For mobile, imageFile is File
        request.files.add(
          await http.MultipartFile.fromPath('image', imageFile.path),
        );
      }

      var response = await request.send();
      var responseBody = await response.stream.bytesToString();

      if (response.statusCode == 201) {
        final data = jsonDecode(responseBody);
        return RecipeResponse.fromJson(data);
      } else {
        String errorMessage = 'Upload failed';
        try {
          if (responseBody.isNotEmpty) {
            final error = jsonDecode(responseBody);
            errorMessage = error['message'] ?? errorMessage;
          }
        } catch (e) {
          errorMessage = 'Server error (${response.statusCode})';
        }
        throw Exception(errorMessage);
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Get user's recipe history
  static Future<HistoryResponse> getRecipeHistory() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/history'),
        headers: _headers,
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print('History API Response: $data'); // Debug log
        return HistoryResponse.fromJson(data);
      } else {
        String errorMessage = 'Failed to fetch history';
        try {
          if (response.body.isNotEmpty) {
            final error = jsonDecode(response.body);
            errorMessage = error['message'] ?? errorMessage;
          }
        } catch (e) {
          errorMessage = 'Server error (${response.statusCode})';
        }
        print('History API Error: $errorMessage'); // Debug log
        throw Exception(errorMessage);
      }
    } catch (e) {
      print('History API Exception: $e'); // Debug log
      throw Exception('Network error: $e');
    }
  }

  // Alias for getRecipeHistory
  static Future<HistoryResponse?> getHistory() async {
    try {
      return await getRecipeHistory();
    } catch (e) {
      print('Get History Error: $e');
      return null;
    }
  }

  // Toggle favorite status
  static Future<bool> toggleFavorite(int recipeId, bool isFavorite) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/history'),
        headers: _headers,
        body: jsonEncode({
          'recipe_id': recipeId,
          'is_favorite': isFavorite ? 1 : 0,
        }),
      );

      return response.statusCode == 200;
    } catch (e) {
      print('Toggle Favorite Error: $e');
      return false;
    }
  }

  // Delete recipe
  static Future<bool> deleteRecipe(int recipeId) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/history'),
        headers: _headers,
        body: jsonEncode({'recipe_id': recipeId}),
      );

      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  // Generic PUT request
  static Future<Map<String, dynamic>> put(
    String endpoint, {
    Map<String, String>? headers,
    Map<String, dynamic>? body,
  }) async {
    try {
      Map<String, String> requestHeaders = Map.from(_headers);
      if (headers != null) {
        requestHeaders.addAll(headers);
      }

      final response = await http.put(
        Uri.parse('$baseUrl$endpoint'),
        headers: requestHeaders,
        body: body != null ? jsonEncode(body) : null,
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        return jsonDecode(response.body);
      } else {
        String errorMessage = 'Request failed';
        try {
          if (response.body.isNotEmpty) {
            final error = jsonDecode(response.body);
            errorMessage = error['message'] ?? errorMessage;
          }
        } catch (e) {
          errorMessage = 'Server error (${response.statusCode})';
        }
        throw Exception(errorMessage);
      }
    } catch (e) {
      throw Exception('Network error: $e');
    }
  }

  // Logout
  static void logout() {
    _token = null;
  }
}
