import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';

class ApiTestService {
  // Test koneksi ke API hosting
  static Future<Map<String, dynamic>> testConnection() async {
    try {
      print('Testing API connection to: ${AppConfig.baseUrl}');
      
      final response = await http.get(
        Uri.parse('${AppConfig.baseUrl}/'),
        headers: {
          'Content-Type': 'application/json',
        },
      ).timeout(Duration(seconds: 10));

      print('Response Status: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        return {
          'success': true,
          'message': 'API connection successful',
          'status_code': response.statusCode,
          'response': response.body,
        };
      } else {
        return {
          'success': false,
          'message': 'API connection failed',
          'status_code': response.statusCode,
          'response': response.body,
        };
      }
    } catch (e) {
      print('API Test Error: $e');
      return {
        'success': false,
        'message': 'Connection error: $e',
        'error': e.toString(),
      };
    }
  }

  // Test endpoint auth
  static Future<Map<String, dynamic>> testAuthEndpoint() async {
    try {
      print('Testing Auth endpoint: ${AppConfig.baseUrl}/auth');
      
      final response = await http.post(
        Uri.parse('${AppConfig.baseUrl}/auth'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'action': 'test',
        }),
      ).timeout(Duration(seconds: 10));

      print('Auth Response Status: ${response.statusCode}');
      print('Auth Response Body: ${response.body}');

      return {
        'success': response.statusCode < 500,
        'status_code': response.statusCode,
        'response': response.body,
      };
    } catch (e) {
      print('Auth Test Error: $e');
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  // Test endpoint upload
  static Future<Map<String, dynamic>> testUploadEndpoint() async {
    try {
      print('Testing Upload endpoint: ${AppConfig.baseUrl}/upload');
      
      final response = await http.post(
        Uri.parse('${AppConfig.baseUrl}/upload'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'test': 'data',
        }),
      ).timeout(Duration(seconds: 10));

      print('Upload Response Status: ${response.statusCode}');
      print('Upload Response Body: ${response.body}');

      return {
        'success': response.statusCode < 500,
        'status_code': response.statusCode,
        'response': response.body,
      };
    } catch (e) {
      print('Upload Test Error: $e');
      return {
        'success': false,
        'error': e.toString(),
      };
    }
  }

  // Test semua endpoint sekaligus
  static Future<Map<String, dynamic>> testAllEndpoints() async {
    print('=== TESTING ALL API ENDPOINTS ===');
    print('Base URL: ${AppConfig.baseUrl}');
    
    final results = <String, dynamic>{};
    
    // Test connection
    results['connection'] = await testConnection();
    
    // Test auth endpoint
    results['auth'] = await testAuthEndpoint();
    
    // Test upload endpoint
    results['upload'] = await testUploadEndpoint();
    
    print('=== TEST RESULTS ===');
    print('Connection: ${results['connection']['success']}');
    print('Auth: ${results['auth']['success']}');
    print('Upload: ${results['upload']['success']}');
    
    return results;
  }
}
