import 'package:flutter/material.dart';

class AppTheme {
  // Colors from Kotlin project
  static const Color primaryOrange = Color(0xFFf0b237);
  static const Color primaryBackground = Color(0xFFF4E4);
  static const Color cardBackground = Color(0xFFfff4e3);
  static const Color textDark = Color(0xFF000101);
  static const Color textSoftDark = Color(0xFF505950);
  static const Color white = Color(0xFFFFFFFF);
  
  // Gradient colors
  static const Color cardStart = Color(0xFFFFF8EE);
  static const Color cardEnd = Color(0xFFFFFFFF);
  
  // Additional colors for better design
  static const Color lightOrange = Color(0xFFFFF4E3);
  static const Color darkOrange = Color(0xFFE09B2A);
  static const Color shadowColor = Color(0x1A000000);

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: primaryOrange,
        brightness: Brightness.light,
        primary: primaryOrange,
        secondary: darkOrange,
        surface: white,
        background: primaryBackground,
      ),
      scaffoldBackgroundColor: primaryBackground,
      fontFamily: 'Sniglet',
      appBarTheme: AppBarTheme(
        backgroundColor: primaryOrange,
        foregroundColor: textDark,
        elevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontFamily: 'Sniglet',
          fontSize: 20,
          fontWeight: FontWeight.bold,
          color: textDark,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primaryOrange,
          foregroundColor: textDark,
          elevation: 2,
          shadowColor: shadowColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        ),
      ),
      cardTheme: CardThemeData(
        color: cardBackground,
        elevation: 2,
        shadowColor: shadowColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: cardBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: primaryOrange, width: 2),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      ),
      bottomNavigationBarTheme: BottomNavigationBarThemeData(
        backgroundColor: white,
        selectedItemColor: primaryOrange,
        unselectedItemColor: textSoftDark,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
        selectedLabelStyle: TextStyle(
          fontFamily: 'Sniglet',
          fontWeight: FontWeight.w600,
        ),
        unselectedLabelStyle: TextStyle(
          fontFamily: 'Sniglet',
        ),
      ),
    );
  }
}
