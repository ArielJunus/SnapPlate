class Recipe {
  final int id;
  final int userId;
  final String imagePath;
  final String recipeContent;
  final bool isFavorite;
  final DateTime createdAt;

  Recipe({
    required this.id,
    required this.userId,
    required this.imagePath,
    required this.recipeContent,
    required this.isFavorite,
    required this.createdAt,
  });

  factory Recipe.fromJson(Map<String, dynamic> json) {
    return Recipe(
      id: _parseInt(json['id']) ?? 0,
      userId: _parseInt(json['user_id']) ?? 0,
      imagePath: json['image_path'] ?? '',
      recipeContent: json['recipe_content'] ?? '',
      isFavorite: _parseInt(json['is_favorite']) == 1,
      createdAt: json['created_at'] != null 
          ? DateTime.parse(json['created_at'])
          : DateTime.now(),
    );
  }

  // Helper method untuk parsing int dari string atau int
  static int? _parseInt(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    if (value is String) {
      return int.tryParse(value);
    }
    return null;
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'user_id': userId,
      'image_path': imagePath,
      'recipe_content': recipeContent,
      'is_favorite': isFavorite ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
    };
  }
}

class RecipeResponse {
  final String message;
  final String? recipe;
  final String? imagePath;

  RecipeResponse({
    required this.message,
    this.recipe,
    this.imagePath,
  });

  factory RecipeResponse.fromJson(Map<String, dynamic> json) {
    return RecipeResponse(
      message: json['message'],
      recipe: json['recipe'],
      imagePath: json['image_path'],
    );
  }
}

class HistoryResponse {
  final String message;
  final List<Recipe> recipes;

  HistoryResponse({
    required this.message,
    required this.recipes,
  });

  factory HistoryResponse.fromJson(Map<String, dynamic> json) {
    return HistoryResponse(
      message: json['message'] ?? 'Success',
      recipes: json['recipes'] != null 
          ? (json['recipes'] as List)
              .map((recipe) => Recipe.fromJson(recipe))
              .toList()
          : <Recipe>[],
    );
  }
}
