import 'package:flutter/material.dart';
import '../models/recipe.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Recipe> _recipes = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRecipes();
  }

  Future<void> _loadRecipes() async {
    try {
      final response = await ApiService.getRecipeHistory();
      setState(() {
        _recipes = response.recipes;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        // Show a more user-friendly error message
        String errorMessage = 'Unable to load recipe history';
        if (e.toString().contains('Network error')) {
          errorMessage = 'Please check your internet connection';
        } else if (e.toString().contains('Failed to fetch')) {
          errorMessage = 'Server error. Please try again later';
        }
        
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(errorMessage),
            backgroundColor: Colors.red[400],
            action: SnackBarAction(
              label: 'Retry',
              textColor: Colors.white,
              onPressed: _loadRecipes,
            ),
          ),
        );
      }
    }
  }

  Future<void> _deleteRecipe(int recipeId) async {
    try {
      final success = await ApiService.deleteRecipe(recipeId);
      if (success) {
        setState(() {
          _recipes.removeWhere((recipe) => recipe.id == recipeId);
        });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Recipe deleted successfully')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error deleting recipe: $e')),
        );
      }
    }
  }

  Future<void> _toggleFavorite(Recipe recipe) async {
    try {
      final newFavoriteStatus = !recipe.isFavorite;
      await ApiService.toggleFavorite(recipe.id, newFavoriteStatus);
      
      setState(() {
        final index = _recipes.indexWhere((r) => r.id == recipe.id);
        if (index != -1) {
          _recipes[index] = Recipe(
            id: recipe.id,
            userId: recipe.userId,
            imagePath: recipe.imagePath,
            recipeContent: recipe.recipeContent,
            isFavorite: newFavoriteStatus,
            createdAt: recipe.createdAt,
          );
        }
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(newFavoriteStatus ? 'Added to favorites' : 'Removed from favorites'),
            backgroundColor: newFavoriteStatus ? Colors.green[600] : Colors.orange[600],
          ),
        );
      }
    } catch (e) {
      print('Error toggling favorite: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to update favorite status')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBackground,
      appBar: AppBar(
        title: Text(
          'Recipe History',
          style: TextStyle(
            fontFamily: 'Sniglet',
            color: AppTheme.textDark,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: AppTheme.primaryOrange,
        foregroundColor: AppTheme.textDark,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadRecipes,
            tooltip: 'Refresh',
          ),
        ],
      ),
      body: _isLoading
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(
                    color: AppTheme.primaryOrange,
                    strokeWidth: 3,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Loading your recipes...',
                    style: TextStyle(
                      fontSize: 16,
                      color: AppTheme.textSoftDark,
                      fontFamily: 'Sniglet',
                    ),
                  ),
                ],
              ),
            )
          : _recipes.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 120,
                        height: 120,
                        decoration: BoxDecoration(
                          color: AppTheme.primaryOrange.withOpacity(0.1),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.restaurant_menu,
                          size: 60,
                          color: AppTheme.primaryOrange,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Text(
                        'No recipes yet',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.textDark,
                          fontFamily: 'Sniglet',
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Start by taking a photo of your leftovers!',
                        style: TextStyle(
                          fontSize: 16,
                          color: AppTheme.textSoftDark,
                          fontFamily: 'Sniglet',
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 32),
                      ElevatedButton.icon(
                        onPressed: _loadRecipes,
                        icon: const Icon(Icons.refresh),
                        label: const Text('Refresh'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppTheme.primaryOrange,
                          foregroundColor: AppTheme.textDark,
                          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _loadRecipes,
                  color: AppTheme.primaryOrange,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(20),
                    itemCount: _recipes.length,
                    itemBuilder: (context, index) {
                      final recipe = _recipes[index];
                      return _buildRecipeCard(recipe, index);
                    },
                  ),
                ),
    );
  }

  Widget _buildRecipeCard(Recipe recipe, int index) {
    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      child: Card(
        elevation: 8,
        shadowColor: AppTheme.shadowColor,
                        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.white, AppTheme.cardStart],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: AppTheme.primaryOrange.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: InkWell(
            borderRadius: BorderRadius.circular(20),
            onTap: () {
              _showRecipeDetails(recipe, index);
            },
                        child: Padding(
              padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                  // Header with recipe number and date
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryOrange,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          'Recipe ${index + 1}',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.white,
                            fontFamily: 'Sniglet',
                          ),
                        ),
                                  ),
                                  Row(
                                    children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppTheme.primaryOrange.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                                        _formatDate(recipe.createdAt),
                                        style: TextStyle(
                                          fontSize: 12,
                                color: AppTheme.textSoftDark,
                                fontFamily: 'Sniglet',
                                fontWeight: FontWeight.w600,
                              ),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                          // Favorite button
                          Container(
                            decoration: BoxDecoration(
                              color: recipe.isFavorite ? Colors.red[50] : Colors.grey[50],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: IconButton(
                              icon: Icon(
                                recipe.isFavorite ? Icons.favorite : Icons.favorite_border,
                                color: recipe.isFavorite ? Colors.red[400] : Colors.grey[400],
                                size: 20,
                              ),
                              onPressed: () => _toggleFavorite(recipe),
                              padding: const EdgeInsets.all(8),
                              constraints: const BoxConstraints(
                                minWidth: 32,
                                minHeight: 32,
                              ),
                            ),
                          ),
                                      const SizedBox(width: 8),
                          // Delete button
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.red[50],
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: IconButton(
                              icon: Icon(
                                Icons.delete_outline,
                                        color: Colors.red[400],
                                size: 20,
                              ),
                                        onPressed: () {
                                          _showDeleteDialog(recipe.id);
                                        },
                              padding: const EdgeInsets.all(8),
                              constraints: const BoxConstraints(
                                minWidth: 32,
                                minHeight: 32,
                              ),
                            ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                  
                  const SizedBox(height: 16),
                              
                  // Recipe content with better styling
                              Container(
                                width: double.infinity,
                    padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                      color: AppTheme.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: AppTheme.primaryOrange.withOpacity(0.1),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.shadowColor,
                          blurRadius: 4,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Icon(
                              Icons.restaurant_menu,
                              color: AppTheme.primaryOrange,
                              size: 20,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Recipe Preview',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                color: AppTheme.textDark,
                                fontFamily: 'Sniglet',
                                ),
                              ),
                            ],
                        ),
                        const SizedBox(height: 12),
                        Text(
                          recipe.recipeContent,
                          style: TextStyle(
                            fontSize: 14,
                            color: AppTheme.textDark,
                            fontFamily: 'Sniglet',
                            height: 1.4,
                          ),
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 16),
                  
                  // Action button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        _showRecipeDetails(recipe, index);
                      },
                      icon: const Icon(Icons.visibility, size: 16),
                      label: const Text('View Full Recipe'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.primaryOrange,
                        foregroundColor: AppTheme.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
                          ),
                        ),
                      );
  }

  void _showRecipeDetails(Recipe recipe, int index) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          child: Container(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.of(context).size.height * 0.8,
              maxWidth: MediaQuery.of(context).size.width * 0.9,
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(
                colors: [AppTheme.white, AppTheme.cardStart],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Header
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryOrange,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(20),
                      topRight: Radius.circular(20),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Recipe ${index + 1}',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: AppTheme.white,
                          fontFamily: 'Sniglet',
                        ),
                      ),
                      Row(
                        children: [
                          // Favorite button in dialog
                          IconButton(
                            onPressed: () => _toggleFavorite(recipe),
                            icon: Icon(
                              recipe.isFavorite ? Icons.favorite : Icons.favorite_border,
                              color: recipe.isFavorite ? Colors.red[200] : AppTheme.white,
                            ),
                            tooltip: recipe.isFavorite ? 'Remove from favorites' : 'Add to favorites',
                          ),
                          IconButton(
                            onPressed: () => Navigator.of(context).pop(),
                            icon: const Icon(Icons.close),
                            color: AppTheme.white,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                
                // Content
                Flexible(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(20),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppTheme.primaryOrange.withOpacity(0.2),
                        ),
                      ),
                      child: Text(
                        _cleanRecipeContent(recipe.recipeContent),
                        style: TextStyle(
                          fontSize: 16,
                          color: AppTheme.textDark,
                          fontFamily: 'Sniglet',
                          height: 1.5,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _cleanRecipeContent(String content) {
    // Remove markdown headers (# ## ###)
    String cleaned = content
        .replaceAll(RegExp(r'^#{1,6}\s*', multiLine: true), '')
        .replaceAll(RegExp(r'^#{1,6}\s*', multiLine: true), '');
    
    // Clean up any remaining markdown formatting
    cleaned = cleaned
        .replaceAll(RegExp(r'\*\*(.*?)\*\*'), r'$1') // Remove bold
        .replaceAll(RegExp(r'\*(.*?)\*'), r'$1'); // Remove italic
    
    return cleaned;
  }


  void _showDeleteDialog(int recipeId) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Delete Recipe',
            style: TextStyle(
              fontFamily: 'Sniglet',
              color: AppTheme.textDark,
            ),
          ),
          content: Text(
            'Are you sure you want to delete this recipe?',
            style: TextStyle(
              fontFamily: 'Sniglet',
              color: AppTheme.textSoftDark,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                'Cancel',
                style: TextStyle(
                  color: AppTheme.textSoftDark,
                  fontFamily: 'Sniglet',
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
                _deleteRecipe(recipeId);
              },
              child: Text(
                'Delete',
                style: TextStyle(
                  color: Colors.red[600],
                  fontFamily: 'Sniglet',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }
}