import 'package:flutter/material.dart';
import '../theme/app_theme.dart';
import 'camera_screen.dart';
import '../services/auth_service.dart';
import '../services/api_service.dart';
import '../models/recipe.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String _userName = 'User';
  bool _isLoading = true;
  List<Recipe> _recipes = [];
  int _totalRecipes = 0;
  int _favoriteRecipes = 0;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    try {
      final user = await AuthService.getCurrentUser();
      print('Dashboard - Loaded user: ${user?.username}'); // Debug log
      
      // Load recipes data
      await _loadRecipesData();
      
      setState(() {
        _userName = user?.username ?? 'User';
        _isLoading = false;
      });
    } catch (e) {
      print('Dashboard - Error loading user: $e'); // Debug log
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _loadRecipesData() async {
    try {
      final response = await ApiService.getHistory();
      if (response != null) {
        setState(() {
          _recipes = response.recipes;
          _totalRecipes = _recipes.length;
          _favoriteRecipes = _recipes.where((recipe) => recipe.isFavorite).length;
        });
      }
    } catch (e) {
      print('Dashboard - Error loading recipes: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.primaryBackground,
      body: SafeArea(
        child: _isLoading
            ? const Center(
                child: CircularProgressIndicator(
                  color: AppTheme.primaryOrange,
                ),
              )
            : SingleChildScrollView(
                padding: const EdgeInsets.all(24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    
                    // Welcome Header
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [AppTheme.cardStart, AppTheme.cardEnd],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.shadowColor,
                            blurRadius: 10,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                  color: AppTheme.primaryOrange,
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: const Icon(
                                  Icons.person,
                                  color: AppTheme.white,
                                  size: 24,
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Selamat datang,',
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: AppTheme.textSoftDark,
                                        fontFamily: 'Sniglet',
                                      ),
                                    ),
                                    Text(
                                      _userName,
                                      style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.bold,
                                        color: AppTheme.textDark,
                                        fontFamily: 'Sniglet',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'Ready to turn your leftovers into delicious recipes?',
                            style: TextStyle(
                              fontSize: 16,
                              color: AppTheme.textSoftDark,
                              fontFamily: 'Sniglet',
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 32),
                    
                    // Main Action Card
                    _buildActionCard(
                      icon: Icons.center_focus_strong,
                      title: 'Scan Ingredients',
                      subtitle: 'Take a photo of your ingredients and get recipe suggestions',
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const CameraScreen(),
                          ),
                        );
                      },
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Quick Stats
                    Text(
                      'Quick Stats',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.textDark,
                        fontFamily: 'Sniglet',
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Quick Stats - Always in a single row
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.45,
                            child: _buildStatCard(
                              icon: Icons.restaurant_menu,
                              title: 'Recipes',
                              value: _totalRecipes.toString(),
                              color: AppTheme.primaryOrange,
                            ),
                          ),
                          const SizedBox(width: 16),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.45,
                            child: _buildStatCard(
                              icon: Icons.favorite,
                              title: 'Favorites',
                              value: _favoriteRecipes.toString(),
                              color: Colors.red[400]!,
                            ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Recent Activity
                    Text(
                      'Recent Activity',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.textDark,
                        fontFamily: 'Sniglet',
                      ),
                    ),
                    
                    const SizedBox(height: 16),
                    
                    // Recent Activity List
                    _recipes.isEmpty
                        ? _buildEmptyState()
                        : Column(
                            children: _recipes.take(3).map((recipe) {
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 12),
                                child: _buildActivityCard(
                                  icon: Icons.restaurant_menu,
                                  title: _getRecipeTitle(recipe.recipeContent),
                                  subtitle: _getTimeAgo(recipe.createdAt),
                                  isFavorite: recipe.isFavorite,
                                  onTap: () {
                                    Navigator.pushNamed(context, '/history');
                                  },
                                  onFavoriteTap: () => _toggleFavorite(recipe),
                                ),
                              );
                            }).toList(),
                          ),
                  ],
                ),
              ),
      ),
    );
  }

  Widget _buildActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.primaryOrange, AppTheme.darkOrange],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Column(
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  color: AppTheme.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Icon(
                  icon,
                  size: 40,
                  color: AppTheme.white,
                ),
              ),
              const SizedBox(height: 16),
              Text(
                title,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: AppTheme.white,
                  fontFamily: 'Sniglet',
                ),
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: 16,
                  color: AppTheme.white.withOpacity(0.9),
                  fontFamily: 'Sniglet',
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [AppTheme.cardStart, AppTheme.cardEnd],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          children: [
            Icon(
              icon,
              size: 32,
              color: color,
            ),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: AppTheme.textDark,
                fontFamily: 'Sniglet',
              ),
            ),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: AppTheme.textSoftDark,
                fontFamily: 'Sniglet',
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _getRecipeTitle(String recipeContent) {
    // Extract title from recipe content (first line or first 30 characters)
    final lines = recipeContent.split('\n');
    if (lines.isNotEmpty && lines.first.trim().isNotEmpty) {
      return lines.first.trim();
    }
    return recipeContent.length > 30 
        ? '${recipeContent.substring(0, 30)}...'
        : recipeContent;
  }

  String _getTimeAgo(DateTime createdAt) {
    final now = DateTime.now();
    final difference = now.difference(createdAt);
    
    if (difference.inDays > 0) {
      return 'Created ${difference.inDays} day${difference.inDays == 1 ? '' : 's'} ago';
    } else if (difference.inHours > 0) {
      return 'Created ${difference.inHours} hour${difference.inHours == 1 ? '' : 's'} ago';
    } else if (difference.inMinutes > 0) {
      return 'Created ${difference.inMinutes} minute${difference.inMinutes == 1 ? '' : 's'} ago';
    } else {
      return 'Created just now';
    }
  }

  Future<void> _toggleFavorite(Recipe recipe) async {
    try {
      final newFavoriteStatus = !recipe.isFavorite;
      await ApiService.toggleFavorite(recipe.id, newFavoriteStatus);
      
      setState(() {
        final index = _recipes.indexWhere((r) => r.id == recipe.id);
        if (index != -1) {
          _recipes[index] = Recipe(
            id: recipe.id,
            userId: recipe.userId,
            imagePath: recipe.imagePath,
            recipeContent: recipe.recipeContent,
            isFavorite: newFavoriteStatus,
            createdAt: recipe.createdAt,
          );
          _favoriteRecipes = _recipes.where((r) => r.isFavorite).length;
        }
      });
    } catch (e) {
      print('Error toggling favorite: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to update favorite status')),
      );
    }
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [AppTheme.cardStart, AppTheme.cardEnd],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(
            Icons.restaurant_menu,
            size: 48,
            color: AppTheme.textSoftDark,
          ),
          const SizedBox(height: 16),
          Text(
            'No recipes yet',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: AppTheme.textDark,
              fontFamily: 'Sniglet',
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Start by scanning your ingredients!',
            style: TextStyle(
              fontSize: 14,
              color: AppTheme.textSoftDark,
              fontFamily: 'Sniglet',
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildActivityCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool isFavorite = false,
    VoidCallback? onFavoriteTap,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [AppTheme.cardStart, AppTheme.cardEnd],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: AppTheme.primaryOrange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  icon,
                  color: AppTheme.primaryOrange,
                  size: 20,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.textDark,
                        fontFamily: 'Sniglet',
                      ),
                    ),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 14,
                        color: AppTheme.textSoftDark,
                        fontFamily: 'Sniglet',
                      ),
                    ),
                  ],
                ),
              ),
              if (onFavoriteTap != null)
                GestureDetector(
                  onTap: onFavoriteTap,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    child: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: isFavorite ? Colors.red[400] : AppTheme.textSoftDark,
                      size: 20,
                    ),
                  ),
                ),
              const SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios,
                color: AppTheme.textSoftDark,
                size: 16,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
