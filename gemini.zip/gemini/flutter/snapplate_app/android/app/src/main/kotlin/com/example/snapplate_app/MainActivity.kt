package com.example.snapplate_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
